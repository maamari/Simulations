HDF5 version 1.6.9 released on Fri May  1 15:26:44 CDT 2009
==> README.txt <==

Periodic code snapshots are provided at the following URL:
    ftp://ftp.hdfgroup.uiuc.edu/pub/outgoing/hdf5/snapshots
Please read the README.txt file in that directory before working with a 
library snapshot.

The HDF5 website is located at http://hdfgroup.org/products/hdf5/.

Bugs should be reported to help@hdfgroup.org.

